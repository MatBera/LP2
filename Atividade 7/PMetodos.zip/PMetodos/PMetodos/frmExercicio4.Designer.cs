﻿namespace PMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnContLetras = new System.Windows.Forms.Button();
            this.lblFrase = new System.Windows.Forms.Label();
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnContNum = new System.Windows.Forms.Button();
            this.btnPosicao = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnContLetras
            // 
            this.btnContLetras.Location = new System.Drawing.Point(889, 427);
            this.btnContLetras.Margin = new System.Windows.Forms.Padding(4);
            this.btnContLetras.Name = "btnContLetras";
            this.btnContLetras.Size = new System.Drawing.Size(143, 79);
            this.btnContLetras.TabIndex = 19;
            this.btnContLetras.Text = "Contar letras";
            this.btnContLetras.UseVisualStyleBackColor = true;
            this.btnContLetras.Click += new System.EventHandler(this.BtnContLetras_Click);
            // 
            // lblFrase
            // 
            this.lblFrase.AutoSize = true;
            this.lblFrase.Location = new System.Drawing.Point(180, 177);
            this.lblFrase.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFrase.Name = "lblFrase";
            this.lblFrase.Size = new System.Drawing.Size(50, 20);
            this.lblFrase.TabIndex = 14;
            this.lblFrase.Text = "Frase";
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(301, 57);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(849, 302);
            this.rchtxtFrase.TabIndex = 20;
            this.rchtxtFrase.Text = "";
            // 
            // btnContNum
            // 
            this.btnContNum.Location = new System.Drawing.Point(385, 427);
            this.btnContNum.Margin = new System.Windows.Forms.Padding(4);
            this.btnContNum.Name = "btnContNum";
            this.btnContNum.Size = new System.Drawing.Size(143, 79);
            this.btnContNum.TabIndex = 16;
            this.btnContNum.Text = "Contar números";
            this.btnContNum.UseVisualStyleBackColor = true;
            this.btnContNum.Click += new System.EventHandler(this.BtnContNum_Click);
            // 
            // btnPosicao
            // 
            this.btnPosicao.Location = new System.Drawing.Point(637, 427);
            this.btnPosicao.Margin = new System.Windows.Forms.Padding(4);
            this.btnPosicao.Name = "btnPosicao";
            this.btnPosicao.Size = new System.Drawing.Size(143, 79);
            this.btnPosicao.TabIndex = 17;
            this.btnPosicao.Text = "Posição do 1º char em branco";
            this.btnPosicao.UseVisualStyleBackColor = true;
            this.btnPosicao.Click += new System.EventHandler(this.BtnPosicao_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1417, 668);
            this.Controls.Add(this.rchtxtFrase);
            this.Controls.Add(this.btnContLetras);
            this.Controls.Add(this.btnPosicao);
            this.Controls.Add(this.lblFrase);
            this.Controls.Add(this.btnContNum);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.Load += new System.EventHandler(this.FrmExercicio4_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnContLetras;
        private System.Windows.Forms.Label lblFrase;
        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnContNum;
        private System.Windows.Forms.Button btnPosicao;
    }
}