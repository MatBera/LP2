﻿namespace INSS_E_IRPF
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalBruto = new System.Windows.Forms.Label();
            this.lblNumFilhos = new System.Windows.Forms.Label();
            this.lblAliINSS = new System.Windows.Forms.Label();
            this.lblAliIRPF = new System.Windows.Forms.Label();
            this.lblSalFamilia = new System.Windows.Forms.Label();
            this.lblSalLíquido = new System.Windows.Forms.Label();
            this.lblDesIRPF = new System.Windows.Forms.Label();
            this.lblDesINSS = new System.Windows.Forms.Label();
            this.txtNomeFunc = new System.Windows.Forms.TextBox();
            this.txtAliINSS = new System.Windows.Forms.TextBox();
            this.txtAliIRPF = new System.Windows.Forms.TextBox();
            this.txtSalFamilia = new System.Windows.Forms.TextBox();
            this.txtSalLiquido = new System.Windows.Forms.TextBox();
            this.txtDesINSS = new System.Windows.Forms.TextBox();
            this.txtDesIRPF = new System.Windows.Forms.TextBox();
            this.mskbSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.numudFilhos = new System.Windows.Forms.NumericUpDown();
            this.errorSalBruto = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorNomeFunc = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.numudFilhos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorSalBruto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorNomeFunc)).BeginInit();
            this.SuspendLayout();
            // 
            // btnVerificar
            // 
            this.btnVerificar.Location = new System.Drawing.Point(234, 159);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(174, 41);
            this.btnVerificar.TabIndex = 4;
            this.btnVerificar.Text = "Verificar";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click_1);
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(26, 33);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(139, 17);
            this.lblNome.TabIndex = 1;
            this.lblNome.Text = "Nome do funcionário";
            // 
            // lblSalBruto
            // 
            this.lblSalBruto.AutoSize = true;
            this.lblSalBruto.Location = new System.Drawing.Point(26, 75);
            this.lblSalBruto.Name = "lblSalBruto";
            this.lblSalBruto.Size = new System.Drawing.Size(89, 17);
            this.lblSalBruto.TabIndex = 2;
            this.lblSalBruto.Text = "Salário bruto";
            // 
            // lblNumFilhos
            // 
            this.lblNumFilhos.AutoSize = true;
            this.lblNumFilhos.Location = new System.Drawing.Point(26, 117);
            this.lblNumFilhos.Name = "lblNumFilhos";
            this.lblNumFilhos.Size = new System.Drawing.Size(115, 17);
            this.lblNumFilhos.TabIndex = 3;
            this.lblNumFilhos.Text = "Número de filhos";
            // 
            // lblAliINSS
            // 
            this.lblAliINSS.AutoSize = true;
            this.lblAliINSS.Location = new System.Drawing.Point(26, 225);
            this.lblAliINSS.Name = "lblAliINSS";
            this.lblAliINSS.Size = new System.Drawing.Size(94, 17);
            this.lblAliINSS.TabIndex = 4;
            this.lblAliINSS.Text = "Alíquota INSS";
            // 
            // lblAliIRPF
            // 
            this.lblAliIRPF.AutoSize = true;
            this.lblAliIRPF.Location = new System.Drawing.Point(26, 267);
            this.lblAliIRPF.Name = "lblAliIRPF";
            this.lblAliIRPF.Size = new System.Drawing.Size(93, 17);
            this.lblAliIRPF.TabIndex = 5;
            this.lblAliIRPF.Text = "Alíquota IRPF";
            // 
            // lblSalFamilia
            // 
            this.lblSalFamilia.AutoSize = true;
            this.lblSalFamilia.Location = new System.Drawing.Point(26, 309);
            this.lblSalFamilia.Name = "lblSalFamilia";
            this.lblSalFamilia.Size = new System.Drawing.Size(100, 17);
            this.lblSalFamilia.TabIndex = 6;
            this.lblSalFamilia.Text = "Salário Família";
            // 
            // lblSalLíquido
            // 
            this.lblSalLíquido.AutoSize = true;
            this.lblSalLíquido.Location = new System.Drawing.Point(26, 351);
            this.lblSalLíquido.Name = "lblSalLíquido";
            this.lblSalLíquido.Size = new System.Drawing.Size(102, 17);
            this.lblSalLíquido.TabIndex = 7;
            this.lblSalLíquido.Text = "Salário Líquido";
            // 
            // lblDesIRPF
            // 
            this.lblDesIRPF.AutoSize = true;
            this.lblDesIRPF.Location = new System.Drawing.Point(392, 267);
            this.lblDesIRPF.Name = "lblDesIRPF";
            this.lblDesIRPF.Size = new System.Drawing.Size(102, 17);
            this.lblDesIRPF.TabIndex = 9;
            this.lblDesIRPF.Text = "Desconto IRPF";
            // 
            // lblDesINSS
            // 
            this.lblDesINSS.AutoSize = true;
            this.lblDesINSS.Location = new System.Drawing.Point(392, 225);
            this.lblDesINSS.Name = "lblDesINSS";
            this.lblDesINSS.Size = new System.Drawing.Size(103, 17);
            this.lblDesINSS.TabIndex = 8;
            this.lblDesINSS.Text = "Desconto INSS";
            // 
            // txtNomeFunc
            // 
            this.txtNomeFunc.Location = new System.Drawing.Point(172, 30);
            this.txtNomeFunc.Name = "txtNomeFunc";
            this.txtNomeFunc.Size = new System.Drawing.Size(175, 23);
            this.txtNomeFunc.TabIndex = 1;
            this.txtNomeFunc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNomeFunc_KeyPress);
            this.txtNomeFunc.Validated += new System.EventHandler(this.txtNomeFunc_Validated_1);
            // 
            // txtAliINSS
            // 
            this.txtAliINSS.Location = new System.Drawing.Point(172, 222);
            this.txtAliINSS.Name = "txtAliINSS";
            this.txtAliINSS.ReadOnly = true;
            this.txtAliINSS.Size = new System.Drawing.Size(175, 23);
            this.txtAliINSS.TabIndex = 13;
            // 
            // txtAliIRPF
            // 
            this.txtAliIRPF.Location = new System.Drawing.Point(172, 264);
            this.txtAliIRPF.Name = "txtAliIRPF";
            this.txtAliIRPF.ReadOnly = true;
            this.txtAliIRPF.Size = new System.Drawing.Size(175, 23);
            this.txtAliIRPF.TabIndex = 14;
            // 
            // txtSalFamilia
            // 
            this.txtSalFamilia.Location = new System.Drawing.Point(172, 306);
            this.txtSalFamilia.Name = "txtSalFamilia";
            this.txtSalFamilia.ReadOnly = true;
            this.txtSalFamilia.Size = new System.Drawing.Size(175, 23);
            this.txtSalFamilia.TabIndex = 15;
            // 
            // txtSalLiquido
            // 
            this.txtSalLiquido.Location = new System.Drawing.Point(172, 348);
            this.txtSalLiquido.Name = "txtSalLiquido";
            this.txtSalLiquido.ReadOnly = true;
            this.txtSalLiquido.Size = new System.Drawing.Size(175, 23);
            this.txtSalLiquido.TabIndex = 16;
            // 
            // txtDesINSS
            // 
            this.txtDesINSS.Location = new System.Drawing.Point(515, 222);
            this.txtDesINSS.Name = "txtDesINSS";
            this.txtDesINSS.ReadOnly = true;
            this.txtDesINSS.Size = new System.Drawing.Size(175, 23);
            this.txtDesINSS.TabIndex = 17;
            // 
            // txtDesIRPF
            // 
            this.txtDesIRPF.Location = new System.Drawing.Point(515, 264);
            this.txtDesIRPF.Name = "txtDesIRPF";
            this.txtDesIRPF.ReadOnly = true;
            this.txtDesIRPF.Size = new System.Drawing.Size(175, 23);
            this.txtDesIRPF.TabIndex = 18;
            // 
            // mskbSalBruto
            // 
            this.mskbSalBruto.Location = new System.Drawing.Point(172, 72);
            this.mskbSalBruto.Mask = "00000.00";
            this.mskbSalBruto.Name = "mskbSalBruto";
            this.mskbSalBruto.Size = new System.Drawing.Size(175, 23);
            this.mskbSalBruto.TabIndex = 2;
            this.mskbSalBruto.Validated += new System.EventHandler(this.mskbSalBruto_Validated_1);
            // 
            // numudFilhos
            // 
            this.numudFilhos.Location = new System.Drawing.Point(172, 117);
            this.numudFilhos.Name = "numudFilhos";
            this.numudFilhos.Size = new System.Drawing.Size(175, 23);
            this.numudFilhos.TabIndex = 3;
            // 
            // errorSalBruto
            // 
            this.errorSalBruto.ContainerControl = this;
            // 
            // errorNomeFunc
            // 
            this.errorNomeFunc.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(757, 437);
            this.Controls.Add(this.numudFilhos);
            this.Controls.Add(this.mskbSalBruto);
            this.Controls.Add(this.txtDesIRPF);
            this.Controls.Add(this.txtDesINSS);
            this.Controls.Add(this.txtSalLiquido);
            this.Controls.Add(this.txtSalFamilia);
            this.Controls.Add(this.txtAliIRPF);
            this.Controls.Add(this.txtAliINSS);
            this.Controls.Add(this.txtNomeFunc);
            this.Controls.Add(this.lblDesIRPF);
            this.Controls.Add(this.lblDesINSS);
            this.Controls.Add(this.lblSalLíquido);
            this.Controls.Add(this.lblSalFamilia);
            this.Controls.Add(this.lblAliIRPF);
            this.Controls.Add(this.lblAliINSS);
            this.Controls.Add(this.lblNumFilhos);
            this.Controls.Add(this.lblSalBruto);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.btnVerificar);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.numudFilhos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorSalBruto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorNomeFunc)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalBruto;
        private System.Windows.Forms.Label lblNumFilhos;
        private System.Windows.Forms.Label lblAliINSS;
        private System.Windows.Forms.Label lblAliIRPF;
        private System.Windows.Forms.Label lblSalFamilia;
        private System.Windows.Forms.Label lblSalLíquido;
        private System.Windows.Forms.Label lblDesIRPF;
        private System.Windows.Forms.Label lblDesINSS;
        private System.Windows.Forms.TextBox txtNomeFunc;
        private System.Windows.Forms.TextBox txtAliINSS;
        private System.Windows.Forms.TextBox txtAliIRPF;
        private System.Windows.Forms.TextBox txtSalFamilia;
        private System.Windows.Forms.TextBox txtSalLiquido;
        private System.Windows.Forms.TextBox txtDesINSS;
        private System.Windows.Forms.TextBox txtDesIRPF;
        private System.Windows.Forms.MaskedTextBox mskbSalBruto;
        private System.Windows.Forms.NumericUpDown numudFilhos;
        private System.Windows.Forms.ErrorProvider errorSalBruto;
        private System.Windows.Forms.ErrorProvider errorNomeFunc;
    }
}

