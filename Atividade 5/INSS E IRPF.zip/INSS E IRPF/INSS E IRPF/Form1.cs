﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace INSS_E_IRPF
{
    public partial class Form1 : Form
    {
        double SalBruto, SalFamilia, SalLiquido, DescINSS, DescIRPF;
        int NumFilhos;

        private void txtNomeFunc_Validated_1(object sender, EventArgs e)
        {
            errorNomeFunc.Clear();

            if (txtNomeFunc.Text == null)
            {
                errorNomeFunc.SetError(txtNomeFunc, "Digite o nome!");
            }
        }

        private void mskbSalBruto_Validated_1(object sender, EventArgs e)
        {
            errorSalBruto.Clear();

            if (mskbSalBruto.Text == "")
            {
                errorSalBruto.SetError(mskbSalBruto, "Valor de salário inválido!");
            }
        }

        private void txtNomeFunc_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && e.KeyChar != ' ' && e.KeyChar != '8')
            {
                errorSalBruto.SetError(txtNomeFunc, "Use apenas letras!");
            }
        }

        private void btnVerificar_Click_1(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbSalBruto.Text, out SalBruto))
            {
                MessageBox.Show("Todos os campos devem ser preenchidos corretamente!");

                mskbSalBruto.Focus();
            }
            else
            {
                Double.TryParse(mskbSalBruto.Text, out SalBruto);
                int.TryParse(numudFilhos.Text, out NumFilhos);

                if (SalBruto <= 800.47)
                {
                    txtAliINSS.Text = "7,65%";
                    DescINSS = 0.0765 * SalBruto;
                }
                else if (SalBruto <= 1050)
                {
                    txtAliINSS.Text = "8,65%";
                    DescINSS = 0.0865 * SalBruto;
                }
                else if (SalBruto <= 1400.17)
                {
                    txtAliINSS.Text = "9,00%";
                    DescINSS = 0.09 * SalBruto;
                }
                else if (SalBruto <= 2801.56)
                {
                    txtAliINSS.Text = "11,00%";
                    DescINSS = 0.11 * SalBruto;
                }
                else
                {
                    txtAliINSS.Text = "27,50%";
                    DescINSS = 0.275 * SalBruto;
                }

                if (SalBruto <= 1257.12)
                {
                    txtAliIRPF.Text = "Insento";
                    DescIRPF = 0;
                }
                else if (SalBruto <= 2512.08)
                {
                    txtAliIRPF.Text = "15,00%";
                    DescIRPF = 0.15 * SalBruto;
                }
                else
                {
                    txtAliIRPF.Text = "27,50%";
                    DescIRPF = 0.275 * SalBruto;
                }

                if (SalBruto <= 435.32)
                {
                    SalFamilia = NumFilhos * 22.33;
                    txtSalFamilia.Text = SalFamilia.ToString();
                }
                else if (SalBruto <= 654.61)
                {
                    SalFamilia = NumFilhos * 15.74;
                    txtSalFamilia.Text = SalFamilia.ToString();
                }
                else
                {
                    txtSalFamilia.Text = "R$ 0,00";
                    SalFamilia = 0;
                }

                txtDesINSS.Text = DescINSS.ToString();
                txtDesIRPF.Text = DescIRPF.ToString();

                SalLiquido = SalBruto + SalFamilia - DescINSS - DescIRPF;
                txtSalLiquido.Text = SalLiquido.ToString();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
