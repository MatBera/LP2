﻿
namespace IMC2
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnCalc = new System.Windows.Forms.Button();
            this.lblimc = new System.Windows.Forms.Label();
            this.lblaltura = new System.Windows.Forms.Label();
            this.lblmassa = new System.Windows.Forms.Label();
            this.mtxtbAltura = new System.Windows.Forms.MaskedTextBox();
            this.mtxtbMassa = new System.Windows.Forms.MaskedTextBox();
            this.txtIMC = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(215, 265);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(106, 57);
            this.btnLimpar.TabIndex = 5;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(378, 265);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(106, 57);
            this.btnSair.TabIndex = 6;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(52, 265);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(106, 57);
            this.btnCalc.TabIndex = 4;
            this.btnCalc.Text = "Calcular";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btncalc_Click);
            // 
            // lblimc
            // 
            this.lblimc.AutoSize = true;
            this.lblimc.Location = new System.Drawing.Point(69, 174);
            this.lblimc.Name = "lblimc";
            this.lblimc.Size = new System.Drawing.Size(38, 20);
            this.lblimc.TabIndex = 11;
            this.lblimc.Text = "IMC";
            // 
            // lblaltura
            // 
            this.lblaltura.AutoSize = true;
            this.lblaltura.Location = new System.Drawing.Point(69, 124);
            this.lblaltura.Name = "lblaltura";
            this.lblaltura.Size = new System.Drawing.Size(78, 20);
            this.lblaltura.TabIndex = 10;
            this.lblaltura.Text = "Altura (m)";
            // 
            // lblmassa
            // 
            this.lblmassa.AutoSize = true;
            this.lblmassa.Location = new System.Drawing.Point(69, 74);
            this.lblmassa.Name = "lblmassa";
            this.lblmassa.Size = new System.Drawing.Size(89, 20);
            this.lblmassa.TabIndex = 9;
            this.lblmassa.Text = "Massa (Kg)";
            // 
            // mtxtbAltura
            // 
            this.mtxtbAltura.BackColor = System.Drawing.SystemColors.Window;
            this.mtxtbAltura.Location = new System.Drawing.Point(186, 121);
            this.mtxtbAltura.Mask = "900.00";
            this.mtxtbAltura.Name = "mtxtbAltura";
            this.mtxtbAltura.Size = new System.Drawing.Size(57, 26);
            this.mtxtbAltura.TabIndex = 2;
            this.mtxtbAltura.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.mtxtbAltura.TextMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals;
            this.mtxtbAltura.Validated += new System.EventHandler(this.mtxtbAltura_Validated);
            // 
            // mtxtbMassa
            // 
            this.mtxtbMassa.BackColor = System.Drawing.SystemColors.Window;
            this.mtxtbMassa.Location = new System.Drawing.Point(186, 71);
            this.mtxtbMassa.Mask = "900.00";
            this.mtxtbMassa.Name = "mtxtbMassa";
            this.mtxtbMassa.Size = new System.Drawing.Size(57, 26);
            this.mtxtbMassa.TabIndex = 1;
            this.mtxtbMassa.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.mtxtbMassa.TextMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals;
            this.mtxtbMassa.Validated += new System.EventHandler(this.mtxtbMassa_Validated);
            // 
            // txtIMC
            // 
            this.txtIMC.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtIMC.Location = new System.Drawing.Point(186, 171);
            this.txtIMC.Name = "txtIMC";
            this.txtIMC.ReadOnly = true;
            this.txtIMC.Size = new System.Drawing.Size(57, 26);
            this.txtIMC.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(716, 427);
            this.Controls.Add(this.txtIMC);
            this.Controls.Add(this.mtxtbMassa);
            this.Controls.Add(this.mtxtbAltura);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.lblimc);
            this.Controls.Add(this.lblaltura);
            this.Controls.Add(this.lblmassa);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Label lblimc;
        private System.Windows.Forms.Label lblaltura;
        private System.Windows.Forms.Label lblmassa;
        private System.Windows.Forms.MaskedTextBox mtxtbAltura;
        private System.Windows.Forms.MaskedTextBox mtxtbMassa;
        private System.Windows.Forms.TextBox txtIMC;
    }
}

