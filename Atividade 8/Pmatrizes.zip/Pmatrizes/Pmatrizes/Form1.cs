﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string saida = "";
            for(var i=0; i<20; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i+1}º dos 20 números, um de cada vez.", "Entrada de dados");

                if (auxiliar == "")
                    return;
                if(!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Valor inválido!");
                    i--;
                }
                else
                {
                    saida = vetor[i] + "\n" + saida;
                }
            }

            /*Array.Reverse(vetor);
            auxiliar = "";
            foreach (var x in vetor)
                auxiliar += x +"\n";
            MessageBox.Show(auxiliar);*/

            MessageBox.Show(saida);
        }

        private void BtnExercicio2_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string auxiliar = "";
            double [] media;

            for (var aluno = 0; aluno < 20; aluno++)
            {
                for (var nota = 0; nota < 3; nota++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {nota + 1} do aluno {aluno + 1}.", "Entrada de dados");

                    if (auxiliar == "")
                        return;

                    if (!double.TryParse(auxiliar, out notas[aluno, nota]) || notas[aluno, nota] < 0 || notas[aluno, nota] > 10)
                    {
                        MessageBox.Show("Valor inválido!");
                        nota--;
                    }
                }
            }

            for (var aluno = 0; aluno < 20; aluno++)
            {
                media[aluno] = (notas[aluno, 1] + notas[aluno, 2] + notas[aluno, 3]) / 3;
            }
        }
    }
}
