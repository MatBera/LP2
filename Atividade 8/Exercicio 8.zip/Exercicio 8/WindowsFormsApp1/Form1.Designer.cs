﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInversor = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.btnLaco = new System.Windows.Forms.Button();
            this.btnRemocao = new System.Windows.Forms.Button();
            this.btnContagem = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnInversor
            // 
            this.btnInversor.Location = new System.Drawing.Point(269, 168);
            this.btnInversor.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnInversor.Name = "btnInversor";
            this.btnInversor.Size = new System.Drawing.Size(177, 102);
            this.btnInversor.TabIndex = 0;
            this.btnInversor.Text = "Inversor";
            this.btnInversor.UseVisualStyleBackColor = true;
            this.btnInversor.Click += new System.EventHandler(this.btnInversor_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.Location = new System.Drawing.Point(606, 168);
            this.btnMedia.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(170, 102);
            this.btnMedia.TabIndex = 1;
            this.btnMedia.Text = "Média";
            this.btnMedia.UseVisualStyleBackColor = true;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // btnLaco
            // 
            this.btnLaco.Location = new System.Drawing.Point(936, 168);
            this.btnLaco.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnLaco.Name = "btnLaco";
            this.btnLaco.Size = new System.Drawing.Size(158, 102);
            this.btnLaco.TabIndex = 2;
            this.btnLaco.Text = "Laço";
            this.btnLaco.UseVisualStyleBackColor = true;
            this.btnLaco.Click += new System.EventHandler(this.btnLaco_Click);
            // 
            // btnRemocao
            // 
            this.btnRemocao.Location = new System.Drawing.Point(429, 385);
            this.btnRemocao.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnRemocao.Name = "btnRemocao";
            this.btnRemocao.Size = new System.Drawing.Size(178, 125);
            this.btnRemocao.TabIndex = 3;
            this.btnRemocao.Text = "Remoção";
            this.btnRemocao.UseVisualStyleBackColor = true;
            this.btnRemocao.Click += new System.EventHandler(this.btnRemocao_Click);
            // 
            // btnContagem
            // 
            this.btnContagem.Location = new System.Drawing.Point(776, 385);
            this.btnContagem.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnContagem.Name = "btnContagem";
            this.btnContagem.Size = new System.Drawing.Size(166, 125);
            this.btnContagem.TabIndex = 4;
            this.btnContagem.Text = "Contagem";
            this.btnContagem.UseVisualStyleBackColor = true;
            this.btnContagem.Click += new System.EventHandler(this.btnContagem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1423, 635);
            this.Controls.Add(this.btnContagem);
            this.Controls.Add(this.btnRemocao);
            this.Controls.Add(this.btnLaco);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.btnInversor);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnInversor;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Button btnLaco;
        private System.Windows.Forms.Button btnRemocao;
        private System.Windows.Forms.Button btnContagem;
    }
}

