﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Pdespesa0030482313035
{
    class Tipo
    {
        //atributos
        private int idtipo;
        private string descricaotipo;

        //propriedades
        public int Idtipo
        {
            get
            {
                return idtipo;
            }
            set
            {
                idtipo = value;
            }
        }
        public string Descricaotipo
        {
            get
            {
                return descricaotipo;
            }
            set
            {
                descricaotipo = value;
            }
        }
        public DataTable Listar() //metodo
        {
            SqlDataAdapter daTipo;

            DataTable dtTipo = new DataTable();

            try
            {
                daTipo = new SqlDataAdapter("SELECT * FROM TIPO", frmPrincipal.conexao);
                daTipo.Fill(dtTipo);
                daTipo.FillSchema(dtTipo, SchemaType.Source);
            }
            catch (Exception)
            {
                throw; //levantar uma exceção
            }
            return dtTipo;
        }
    }
}
