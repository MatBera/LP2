﻿namespace Pdespesa0030482313035
{
    partial class frmSobre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSobre));
            this.txtMariana = new System.Windows.Forms.TextBox();
            this.txtMatheusAlves = new System.Windows.Forms.TextBox();
            this.txtMatheusBera = new System.Windows.Forms.TextBox();
            this.pctBera = new System.Windows.Forms.PictureBox();
            this.pctAlves = new System.Windows.Forms.PictureBox();
            this.pctMariana = new System.Windows.Forms.PictureBox();
            this.rtxtAlves = new System.Windows.Forms.RichTextBox();
            this.rtxtMariana = new System.Windows.Forms.RichTextBox();
            this.rtxtBera = new System.Windows.Forms.RichTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pctBera)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctAlves)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctMariana)).BeginInit();
            this.SuspendLayout();
            // 
            // txtMariana
            // 
            this.txtMariana.Location = new System.Drawing.Point(51, 19);
            this.txtMariana.Name = "txtMariana";
            this.txtMariana.ReadOnly = true;
            this.txtMariana.Size = new System.Drawing.Size(182, 26);
            this.txtMariana.TabIndex = 0;
            this.txtMariana.Text = "Mariana Alves";
            this.txtMariana.TextChanged += new System.EventHandler(this.TextBox1_TextChanged);
            // 
            // txtMatheusAlves
            // 
            this.txtMatheusAlves.Location = new System.Drawing.Point(302, 19);
            this.txtMatheusAlves.Name = "txtMatheusAlves";
            this.txtMatheusAlves.ReadOnly = true;
            this.txtMatheusAlves.Size = new System.Drawing.Size(181, 26);
            this.txtMatheusAlves.TabIndex = 1;
            this.txtMatheusAlves.Text = "Matheus Alves";
            // 
            // txtMatheusBera
            // 
            this.txtMatheusBera.Location = new System.Drawing.Point(553, 19);
            this.txtMatheusBera.Name = "txtMatheusBera";
            this.txtMatheusBera.ReadOnly = true;
            this.txtMatheusBera.Size = new System.Drawing.Size(181, 26);
            this.txtMatheusBera.TabIndex = 2;
            this.txtMatheusBera.Text = "Mateus Aimo";
            // 
            // pctBera
            // 
            this.pctBera.Image = global::Pdespesa0030482313035.Properties.Resources.Bera;
            this.pctBera.Location = new System.Drawing.Point(552, 79);
            this.pctBera.Name = "pctBera";
            this.pctBera.Size = new System.Drawing.Size(181, 240);
            this.pctBera.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctBera.TabIndex = 5;
            this.pctBera.TabStop = false;
            // 
            // pctAlves
            // 
            this.pctAlves.Image = global::Pdespesa0030482313035.Properties.Resources.Alves;
            this.pctAlves.Location = new System.Drawing.Point(302, 79);
            this.pctAlves.Name = "pctAlves";
            this.pctAlves.Size = new System.Drawing.Size(181, 240);
            this.pctAlves.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctAlves.TabIndex = 4;
            this.pctAlves.TabStop = false;
            // 
            // pctMariana
            // 
            this.pctMariana.Image = global::Pdespesa0030482313035.Properties.Resources.Mariana;
            this.pctMariana.InitialImage = ((System.Drawing.Image)(resources.GetObject("pctMariana.InitialImage")));
            this.pctMariana.Location = new System.Drawing.Point(51, 79);
            this.pctMariana.Name = "pctMariana";
            this.pctMariana.Size = new System.Drawing.Size(181, 240);
            this.pctMariana.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctMariana.TabIndex = 3;
            this.pctMariana.TabStop = false;
            // 
            // rtxtAlves
            // 
            this.rtxtAlves.Location = new System.Drawing.Point(302, 348);
            this.rtxtAlves.Name = "rtxtAlves";
            this.rtxtAlves.ReadOnly = true;
            this.rtxtAlves.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedHorizontal;
            this.rtxtAlves.Size = new System.Drawing.Size(181, 55);
            this.rtxtAlves.TabIndex = 9;
            this.rtxtAlves.Text = "Jogo bola e o Gol que me acerta";
            // 
            // rtxtMariana
            // 
            this.rtxtMariana.Location = new System.Drawing.Point(51, 348);
            this.rtxtMariana.Name = "rtxtMariana";
            this.rtxtMariana.ReadOnly = true;
            this.rtxtMariana.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedHorizontal;
            this.rtxtMariana.Size = new System.Drawing.Size(182, 171);
            this.rtxtMariana.TabIndex = 10;
            this.rtxtMariana.Text = "Dona de Pet Maluca, tenho 1,57m, então  não  do pé na moto. E COM PEQUENOS PROBLE" +
    "MAS VEM GRANDES ACIDENTES - Spider-Dev";
            // 
            // rtxtBera
            // 
            this.rtxtBera.Location = new System.Drawing.Point(552, 348);
            this.rtxtBera.Name = "rtxtBera";
            this.rtxtBera.ReadOnly = true;
            this.rtxtBera.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedHorizontal;
            this.rtxtBera.Size = new System.Drawing.Size(181, 55);
            this.rtxtBera.TabIndex = 11;
            this.rtxtBera.Text = "Logo logo vou saber o que só os loucos sabem";
            // 
            // frmSobre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1021, 635);
            this.Controls.Add(this.rtxtBera);
            this.Controls.Add(this.rtxtMariana);
            this.Controls.Add(this.rtxtAlves);
            this.Controls.Add(this.pctBera);
            this.Controls.Add(this.pctAlves);
            this.Controls.Add(this.pctMariana);
            this.Controls.Add(this.txtMatheusBera);
            this.Controls.Add(this.txtMatheusAlves);
            this.Controls.Add(this.txtMariana);
            this.Name = "frmSobre";
            this.Text = "frmSobre";
            ((System.ComponentModel.ISupportInitialize)(this.pctBera)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctAlves)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctMariana)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMariana;
        private System.Windows.Forms.TextBox txtMatheusAlves;
        private System.Windows.Forms.TextBox txtMatheusBera;
        private System.Windows.Forms.PictureBox pctMariana;
        private System.Windows.Forms.PictureBox pctAlves;
        private System.Windows.Forms.PictureBox pctBera;
        private System.Windows.Forms.RichTextBox rtxtAlves;
        private System.Windows.Forms.RichTextBox rtxtMariana;
        private System.Windows.Forms.RichTextBox rtxtBera;
    }
}