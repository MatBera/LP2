﻿namespace PTestEventos
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblEndereco = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblVale = new System.Windows.Forms.Label();
            this.lblData = new System.Windows.Forms.Label();
            this.lblSalario = new System.Windows.Forms.Label();
            this.btnEnviar = new System.Windows.Forms.Button();
            this.ckbxDependente = new System.Windows.Forms.CheckBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtEndereco = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.mskbxData = new System.Windows.Forms.MaskedTextBox();
            this.mskbxVale = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalario = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(42, 37);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(51, 20);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome";
            // 
            // lblEndereco
            // 
            this.lblEndereco.AutoSize = true;
            this.lblEndereco.Location = new System.Drawing.Point(42, 124);
            this.lblEndereco.Name = "lblEndereco";
            this.lblEndereco.Size = new System.Drawing.Size(78, 20);
            this.lblEndereco.TabIndex = 1;
            this.lblEndereco.Text = "Endereço";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(42, 211);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(53, 20);
            this.lblEmail.TabIndex = 2;
            this.lblEmail.Text = "E-mail";
            // 
            // lblVale
            // 
            this.lblVale.AutoSize = true;
            this.lblVale.Location = new System.Drawing.Point(556, 124);
            this.lblVale.Name = "lblVale";
            this.lblVale.Size = new System.Drawing.Size(133, 20);
            this.lblVale.TabIndex = 3;
            this.lblVale.Text = "Vale Alimentação";
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.Location = new System.Drawing.Point(556, 37);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(154, 20);
            this.lblData.TabIndex = 4;
            this.lblData.Text = "Data de Nascimento";
            // 
            // lblSalario
            // 
            this.lblSalario.AutoSize = true;
            this.lblSalario.Location = new System.Drawing.Point(556, 211);
            this.lblSalario.Name = "lblSalario";
            this.lblSalario.Size = new System.Drawing.Size(58, 20);
            this.lblSalario.TabIndex = 5;
            this.lblSalario.Text = "Salário";
            // 
            // btnEnviar
            // 
            this.btnEnviar.Location = new System.Drawing.Point(314, 579);
            this.btnEnviar.Name = "btnEnviar";
            this.btnEnviar.Size = new System.Drawing.Size(379, 91);
            this.btnEnviar.TabIndex = 8;
            this.btnEnviar.Text = "Enviar Dados";
            this.btnEnviar.UseVisualStyleBackColor = true;
            this.btnEnviar.Enter += new System.EventHandler(this.BtnEnviar_Enter);
            // 
            // ckbxDependente
            // 
            this.ckbxDependente.AutoSize = true;
            this.ckbxDependente.Location = new System.Drawing.Point(46, 308);
            this.ckbxDependente.Name = "ckbxDependente";
            this.ckbxDependente.Size = new System.Drawing.Size(176, 24);
            this.ckbxDependente.TabIndex = 7;
            this.ckbxDependente.Text = "Tem Dependentes?";
            this.ckbxDependente.UseVisualStyleBackColor = true;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(182, 34);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(293, 26);
            this.txtNome.TabIndex = 1;
            this.txtNome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtNome_KeyPress);
            // 
            // txtEndereco
            // 
            this.txtEndereco.Location = new System.Drawing.Point(182, 121);
            this.txtEndereco.Name = "txtEndereco";
            this.txtEndereco.Size = new System.Drawing.Size(293, 26);
            this.txtEndereco.TabIndex = 2;
            this.txtEndereco.Validating += new System.ComponentModel.CancelEventHandler(this.TxtEndereco_Validating);
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(182, 208);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(293, 26);
            this.txtEmail.TabIndex = 3;
            this.txtEmail.Validated += new System.EventHandler(this.TxtEmail_Validated);
            // 
            // mskbxData
            // 
            this.mskbxData.Location = new System.Drawing.Point(754, 31);
            this.mskbxData.Mask = "00/00/0000";
            this.mskbxData.Name = "mskbxData";
            this.mskbxData.Size = new System.Drawing.Size(92, 26);
            this.mskbxData.TabIndex = 4;
            this.mskbxData.ValidatingType = typeof(System.DateTime);
            this.mskbxData.Validated += new System.EventHandler(this.MskbxData_Validated);
            // 
            // mskbxVale
            // 
            this.mskbxVale.Location = new System.Drawing.Point(754, 121);
            this.mskbxVale.Mask = "$ 999.99";
            this.mskbxVale.Name = "mskbxVale";
            this.mskbxVale.Size = new System.Drawing.Size(92, 26);
            this.mskbxVale.TabIndex = 5;
            // 
            // mskbxSalario
            // 
            this.mskbxSalario.Location = new System.Drawing.Point(754, 208);
            this.mskbxSalario.Name = "mskbxSalario";
            this.mskbxSalario.Size = new System.Drawing.Size(92, 26);
            this.mskbxSalario.TabIndex = 6;
            this.mskbxSalario.Leave += new System.EventHandler(this.MskbxSalario_Leave);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(951, 714);
            this.Controls.Add(this.mskbxSalario);
            this.Controls.Add(this.mskbxVale);
            this.Controls.Add(this.mskbxData);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtEndereco);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.ckbxDependente);
            this.Controls.Add(this.btnEnviar);
            this.Controls.Add(this.lblSalario);
            this.Controls.Add(this.lblData);
            this.Controls.Add(this.lblVale);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lblEndereco);
            this.Controls.Add(this.lblNome);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblEndereco;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblVale;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.Label lblSalario;
        private System.Windows.Forms.Button btnEnviar;
        private System.Windows.Forms.CheckBox ckbxDependente;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtEndereco;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.MaskedTextBox mskbxData;
        private System.Windows.Forms.MaskedTextBox mskbxVale;
        private System.Windows.Forms.MaskedTextBox mskbxSalario;
    }
}

