﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTestEventos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            mskbxSalario.Mask = "$9,999.99";
            mskbxSalario.ValidatingType = typeof(System.ComponentModel.DecimalConverter);
            mskbxSalario.PromptChar = ' ';
            mskbxSalario.TextAlign = HorizontalAlignment.Center;
        }

        private void TxtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            Char[] Numeros = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
            bool TemNumero1 = txtNome.Text.Any(c => Numeros.Contains(c));
            if(TemNumero1)
                MessageBox.Show("Não pode ter números!");
        }

        private void TxtEndereco_Validating(object sender, CancelEventArgs e)
        {
            if(txtEndereco.Text == "")
            {
                MessageBox.Show("Endereço inválido!");
                e.Cancel = true;
            }
        }

        private void TxtEmail_Validated(object sender, EventArgs e)
        {
            if(txtEmail.Text == "")
            {
                MessageBox.Show("E-mail inválido!");
                txtEmail.Focus();
            }
        }

        private void MskbxData_Validated(object sender, EventArgs e)
        {
            DateTime dtNasc;

            if(!DateTime.TryParse(mskbxData.Text, out dtNasc))
            {
                MessageBox.Show("Data inválida!");
                mskbxData.Focus();
            }
            else
                MessageBox.Show("A data é: " + dtNasc.ToShortDateString());
        }

        private void MskbxSalario_Leave(object sender, EventArgs e)
        {
            MessageBox.Show("Valor atribuido.");
        }

        private void BtnEnviar_Enter(object sender, EventArgs e)
        {
            MessageBox.Show("Botão pressinado!");
        }
    }
}
